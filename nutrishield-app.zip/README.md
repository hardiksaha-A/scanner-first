# NutriShield (Capacitor / Android)

NutriShield: offline-first food-label scanner: photo or camera -> on-device OCR -> rule-based ingredient analysis.

## Layout
- `www/` - the app that ships (index.html is the live UI + logic; engine.js, smartscan.js, shim.js, ... are loaded by it)
- `www/logo.png` - logo used by the splash and header
- `android-icons/` - launcher icons + native launch splash (applied by the build workflow)
- `scripts/prep.js` - copies the OCR engine into `www/vendor/tess` (run by the workflow)
- `scripts/verify.js` - pre-build sanity check (fails early with a clear message)
- `legacy_unused/` - old files that `index.html` never loaded (not shipped)

## Build
Put this zip in the repository root as `nutrishield-app.zip` (do not unzip; the older name `label-scanner-upload.zip` still works) and add `build.yaml`
as `.github/workflows/build.yaml`. The workflow never replaces files inside the app.
