// Replaces Electron preload bridge (window.api) with in-browser OCR + native-HTTP lookups.
(function () {
  const base = location.origin + '/vendor/tess', IDLE_MS = 90000, START_MS = 50000, READ_MS = 120000;
  let worker = null, workerP = null, chain = Promise.resolve(), idle = null, lastPct = -1;
  const why = e => String((e && e.message) || e || 'unknown error').slice(0, 160);
  // Friendly progress for the screen (api.onProgress is set by the app while a scan runs).
  const logger = m => { try {
    const cb = window.api && window.api.onProgress; if (!cb) return;
    const s = String(m.status || ''), pct = Math.round((m.progress || 0) * 100);
    if (s.indexOf('recogni') >= 0) { if (pct !== lastPct) { lastPct = pct; cb('- reading text ' + pct + '%'); } }
    else if (s.indexOf('language') >= 0) cb('- loading language data');
    else if (s.indexOf('core') >= 0) cb('- starting text reader (first time is slower)');
    else if (s.indexOf('initializ') >= 0) cb('- starting text reader');
  } catch (e) { /* progress is optional */ } };
  function create(blobMode) { // one attempt to start the OCR worker; blobMode=false loads worker.min.js directly
    return new Promise((res, rej) => {
      let late = false; const t = setTimeout(() => { late = true; rej(new Error('text reader did not start in time')); }, START_MS);
      Promise.resolve().then(() => Tesseract.createWorker('eng', 1, {
        workerPath: base + '/worker.min.js', corePath: base + '/core', langPath: base + '/lang',
        workerBlobURL: blobMode, cacheMethod: 'none', logger, errorHandler: e => console.error('[ocr]', e)
      })).then(w => { clearTimeout(t); if (late) { try { w.terminate(); } catch (e) {} } else res(w); }, e => { clearTimeout(t); rej(e); });
    });
  }
  function getWorker() {
    if (worker) return Promise.resolve(worker);
    if (!workerP) workerP = (async () => {
      const errs = [];
      if (typeof Tesseract === 'undefined') { const e = new Error('OCR engine files are missing from the app'); e.ocrFatal = true; throw e; }
      for (const blobMode of [false, true]) { // second try uses a different way of starting the worker
        try { worker = await create(blobMode); api.lastError = ''; return worker; } catch (e) { errs.push(why(e)); console.error('[ocr] start failed (blob=' + blobMode + ')', e); }
      }
      const e = new Error('OCR engine could not start: ' + errs.join(' | ')); e.ocrFatal = true; throw e;
    })().catch(e => { workerP = null; api.lastError = why(e); throw e; });
    return workerP;
  }
  async function reset() { const w = worker; worker = null; workerP = null; if (w) { try { await w.terminate(); } catch (e) {} } }
  // The OCR engine holds ~100 MB; free it when idle so Android does not kill the app in the background.
  const armIdle = () => { clearTimeout(idle); idle = setTimeout(reset, IDLE_MS); };
  // Start loading the engine early (when the user opens the camera or picker) so the first scan feels faster.
  function warmup() { try { clearTimeout(idle); getWorker().then(armIdle, () => {}); } catch (e) { /* OCR not available: scanning will report it */ } }
  // image: Blob, canvas or data URL. Only plain text is requested.
  function scanImage(image) {
    const run = async () => {
      let t; clearTimeout(idle); lastPct = -1;
      try {
        const w = await getWorker();
        const limit = new Promise((_, rej) => { t = setTimeout(() => rej(new Error('reading took too long')), READ_MS); });
        const { data } = await Promise.race([w.recognize(image, {}, { text: true }), limit]);
        return data.text;
      } catch (e) { const fatal = e && e.ocrFatal; await reset(); if (fatal) throw e; throw (e instanceof Error ? e : new Error(why(e))); } finally { clearTimeout(t); armIdle(); }
    };
    const p = chain.then(run, run); chain = p.catch(() => {}); return p;
  }
  const api = window.api = {
    scanImage, warmup, onProgress: null, lastError: '',
    lookupBarcode: c => window.__lookup.fetchProduct(c),
    findSimilar: t => window.__lookup.findSimilar(t)
  };
})();
