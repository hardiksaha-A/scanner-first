// Smart scanner: tries several ways of reading a label photo and keeps the best result.
// v2: trims empty margins, works at a size OCR likes (zooms small print), reads the two halves
// of a busy pack separately, copes with sideways / upside-down photos and uneven light.
(function (root) {
  'use strict';
  const GOOD = 8, POOR = 4, BUDGET = 100000, TARGET = 2400, MAX_UP = 4, DETAIL = 3200; // BUDGET: no new pass after this many ms
  const load = url => new Promise((res, rej) => { const im = new Image(); im.onload = () => res(im); im.onerror = () => rej(new Error('image')); im.src = url; });
  const mk = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };

  // Product shots on a plain background: find the pack itself so its small print gets the pixels.
  function contentBox(im) {
    const W = im.width, H = im.height, s = Math.min(1, 240 / Math.max(W, H)), w = Math.max(16, Math.round(W * s)), h = Math.max(16, Math.round(H * s));
    const c = mk(w, h), x = c.getContext('2d', { willReadFrequently: true }); x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); x.drawImage(im, 0, 0, w, h);
    const d = x.getImageData(0, 0, w, h).data, g = (px, py) => { const q = (py * w + px) * 4; return (d[q] * 299 + d[q + 1] * 587 + d[q + 2] * 114) / 1000; };
    const edge = [];
    for (let i = 0; i < w; i++) edge.push(g(i, 0), g(i, h - 1));
    for (let j = 0; j < h; j++) edge.push(g(0, j), g(w - 1, j));
    edge.sort((a, b) => a - b); const bg = edge[edge.length >> 1];
    let dev = 0; for (const v of edge) dev += Math.abs(v - bg);
    if (dev / edge.length > 8) return null;                         // busy background = a real photo: keep everything
    const T = 24, rows = new Uint16Array(h), cols = new Uint16Array(w), diff = (px, py) => Math.abs(g(px, py) - bg) > T;
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) if (diff(i, j)) rows[j]++;
    let rmax = 0; for (let j = 0; j < h; j++) if (rows[j] > rmax) rmax = rows[j];
    if (!rmax) return null;
    let y0 = 0, y1 = h - 1; while (y0 < h && rows[y0] < rmax * 0.12) y0++; while (y1 > y0 && rows[y1] < rmax * 0.12) y1--;
    for (let j = y0; j <= y1; j++) for (let i = 0; i < w; i++) if (diff(i, j)) cols[i]++;
    let cmax = 0; for (let i = 0; i < w; i++) if (cols[i] > cmax) cmax = cols[i];
    if (!cmax) return null;
    let x0 = 0, x1 = w - 1; while (x0 < w && cols[x0] < cmax * 0.12) x0++; while (x1 > x0 && cols[x1] < cmax * 0.12) x1--;
    const pad = Math.max(3, Math.round(Math.max(w, h) * 0.03));
    x0 = Math.max(0, x0 - pad); y0 = Math.max(0, y0 - pad); x1 = Math.min(w - 1, x1 + pad); y1 = Math.min(h - 1, y1 + pad);
    const bw = x1 - x0 + 1, bh = y1 - y0 + 1;
    if (bw * bh > 0.88 * w * h || bw < w * 0.2 || bh < h * 0.1) return null; // nothing worth trimming, or suspicious
    return { x: Math.floor(x0 / s), y: Math.floor(y0 / s), w: Math.min(W, Math.ceil(bw / s)), h: Math.min(H, Math.ceil(bh / s)) };
  }

  // Bicubic (a = -0.75) resampling of grey values. The canvas upscales with plain linear interpolation,
  // which smears small print; bicubic keeps strokes crisp and reads far better (measured on test labels).
  function cubicW(t) { t = Math.abs(t); const a = -0.75; return t <= 1 ? ((a + 2) * t - (a + 3)) * t * t + 1 : t < 2 ? a * (((t - 5) * t + 8) * t - 4) : 0; }
  function taps(n, dn, k) { // for each output index: 4 source indexes and their weights
    const idx = new Int32Array(dn * 4), wt = new Float32Array(dn * 4);
    for (let i = 0; i < dn; i++) { const p = (i + 0.5) / k - 0.5, i0 = Math.floor(p), f = p - i0, w = [cubicW(f + 1), cubicW(f), cubicW(1 - f), cubicW(2 - f)];
      for (let t = 0; t < 4; t++) { idx[i * 4 + t] = Math.min(n - 1, Math.max(0, i0 - 1 + t)); wt[i * 4 + t] = w[t]; } }
    return { idx, wt };
  }
  function upscaleGray(g, sw, sh, dw, dh) {
    const X = taps(sw, dw, dw / sw), Y = taps(sh, dh, dh / sh), mid = new Float32Array(dw * sh), out = new Uint8ClampedArray(dw * dh);
    for (let y = 0; y < sh; y++) { const r = y * sw, o = y * dw;
      for (let i = 0; i < dw; i++) { const b = i * 4; mid[o + i] = g[r + X.idx[b]] * X.wt[b] + g[r + X.idx[b + 1]] * X.wt[b + 1] + g[r + X.idx[b + 2]] * X.wt[b + 2] + g[r + X.idx[b + 3]] * X.wt[b + 3]; } }
    for (let j = 0; j < dh; j++) { const b = j * 4, r0 = Y.idx[b] * dw, r1 = Y.idx[b + 1] * dw, r2 = Y.idx[b + 2] * dw, r3 = Y.idx[b + 3] * dw, w0 = Y.wt[b], w1 = Y.wt[b + 1], w2 = Y.wt[b + 2], w3 = Y.wt[b + 3], o = j * dw;
      for (let i = 0; i < dw; i++) out[o + i] = mid[r0 + i] * w0 + mid[r1 + i] * w1 + mid[r2 + i] * w2 + mid[r3 + i] * w3; }
    return out;
  }
  function drawUp(im, box, k) { // the box of the source, enlarged by k (> 1) with bicubic resampling, as grey
    const sw = box.w, sh = box.h, s0 = mk(sw, sh), sx = s0.getContext('2d', { willReadFrequently: true });
    sx.fillStyle = '#fff'; sx.fillRect(0, 0, sw, sh); sx.drawImage(im, box.x, box.y, box.w, box.h, 0, 0, sw, sh);
    const d = sx.getImageData(0, 0, sw, sh).data, g = new Uint8ClampedArray(sw * sh);
    for (let i = 0, q = 0; i < g.length; i++, q += 4) g[i] = (d[q] * 299 + d[q + 1] * 587 + d[q + 2] * 114) / 1000;
    const dw = Math.max(1, Math.round(sw * k)), dh = Math.max(1, Math.round(sh * k)), out = upscaleGray(g, sw, sh, dw, dh);
    const c = mk(dw, dh), x = c.getContext('2d', { willReadFrequently: true }), id = x.createImageData(dw, dh), p = id.data;
    for (let i = 0, q = 0; i < out.length; i++, q += 4) { p[q] = p[q + 1] = p[q + 2] = out[i]; p[q + 3] = 255; }
    x.putImageData(id, 0, 0); return c;
  }
  function draw(im, box, k, rot) { // box of the source, scaled by k, turned by 0/90/180/270 degrees
    let base;
    if (k > 1.02) base = drawUp(im, box, k);
    else { const w = Math.max(1, Math.round(box.w * k)), h = Math.max(1, Math.round(box.h * k)); base = mk(w, h);
      const x = base.getContext('2d', { willReadFrequently: true }); x.imageSmoothingQuality = 'high'; x.fillStyle = '#fff'; x.fillRect(0, 0, w, h); x.drawImage(im, box.x, box.y, box.w, box.h, 0, 0, w, h); }
    if (!rot) return base;
    const swap = rot === 90 || rot === 270, c = mk(swap ? base.height : base.width, swap ? base.width : base.height), x = c.getContext('2d', { willReadFrequently: true });
    x.translate(c.width / 2, c.height / 2); x.rotate(rot * Math.PI / 180); x.drawImage(base, -base.width / 2, -base.height / 2); return c;
  }
  function pad(c, f) { // a plain white border: OCR reads text near the edge much better with one
    const m = Math.round(Math.max(c.width, c.height) * f), p = mk(c.width + 2 * m, c.height + 2 * m), x = p.getContext('2d', { willReadFrequently: true });
    x.fillStyle = '#fff'; x.fillRect(0, 0, p.width, p.height); x.drawImage(c, m, m); return p;
  }
  function toGray(c) { // returns {x, d, g}: context, image data, grey values
    const x = c.getContext('2d', { willReadFrequently: true }), d = x.getImageData(0, 0, c.width, c.height), p = d.data, n = c.width * c.height, g = new Uint8ClampedArray(n);
    for (let i = 0, q = 0; i < n; i++, q += 4) g[i] = (p[q] * 299 + p[q + 1] * 587 + p[q + 2] * 114) / 1000;
    return { x, d, g, n };
  }
  function put(o, vals) { const p = o.d.data; for (let i = 0, q = 0; i < o.n; i++, q += 4) p[q] = p[q + 1] = p[q + 2] = vals[i]; o.x.putImageData(o.d, 0, 0); }
  function stretch(c) { // grey + contrast stretch
    const o = toGray(c), h = new Uint32Array(256); o.g.forEach(v => h[v]++);
    let lo = 0, hi = 255, a = 0; while (lo < 255 && (a += h[lo]) < o.n * 0.02) lo++; a = 0; while (hi > 0 && (a += h[hi]) < o.n * 0.02) hi--;
    const s = hi > lo ? 255 / (hi - lo) : 1, out = new Uint8ClampedArray(o.n); for (let i = 0; i < o.n; i++) out[i] = (o.g[i] - lo) * s; put(o, out); return c;
  }
  function binarize(c) { // black text on white, using the local average so shadows and glare do not matter
    const o = toGray(c), w = c.width, h = c.height, I = new Float64Array((w + 1) * (h + 1));
    for (let y = 1; y <= h; y++) { let row = 0; for (let x = 1; x <= w; x++) { row += o.g[(y - 1) * w + x - 1]; I[y * (w + 1) + x] = I[(y - 1) * (w + 1) + x] + row; } }
    const r = Math.max(8, Math.round(Math.min(w, h) / 24)), out = new Uint8ClampedArray(o.n);
    for (let y = 0; y < h; y++) { const y0 = Math.max(0, y - r), y1 = Math.min(h, y + r + 1);
      for (let x = 0; x < w; x++) { const x0 = Math.max(0, x - r), x1 = Math.min(w, x + r + 1), area = (x1 - x0) * (y1 - y0);
        const sum = I[y1 * (w + 1) + x1] - I[y0 * (w + 1) + x1] - I[y1 * (w + 1) + x0] + I[y0 * (w + 1) + x0];
        out[y * w + x] = o.g[y * w + x] < (sum / area) * 0.88 ? 0 : 255; } }
    put(o, out); return c;
  }
  function halves(c) { // two overlapping halves along the long side, so a line on the cut is read whole in one of them
    const w = c.width, h = c.height, wide = w >= h, L = wide ? w : h, ov = Math.round(L * 0.08), half = Math.round(L / 2);
    return [[0, half + ov], [half - ov, L - (half - ov)]].map(([a, len]) => {
      const p = mk(wide ? len : w, wide ? h : len);
      p.getContext('2d', { willReadFrequently: true }).drawImage(c, wide ? a : 0, wide ? 0 : a, p.width, p.height, 0, 0, p.width, p.height); return p; });
  }

  // How useful is this text? More recognised ingredients plus an "Ingredients" heading = better.
  function assess(text) {
    const t = String(text || ''), none = { q: 0, cov: 0, found: 0 }; if (t.trim().length < 8) return none;
    let r; try { r = root.Engine.analyze(t, {}); } catch (e) { return none; }
    return { q: r.found.length * 2 + (/ingredient/i.test(t) ? 4 : 0) + Math.round(r.coverage * 3), cov: r.coverage, found: r.found.length };
  }
  const quality = text => assess(text).q;
  const accept = (a, rot) => a.q >= (rot ? GOOD + 2 : GOOD) && (a.cov >= 0.6 || a.q >= 16); // enough clean ingredients, not just a few lucky words

  const STEP = {
    normal: { label: 'Reading the label', rot: 0, mode: 'gray' },
    zoom: { label: 'Zooming in on the small print', rot: 0, mode: 'gray', split: true, note: 'zoomed in on small print' },
    bin: { label: 'Trying again (uneven light)', rot: 0, mode: 'bin' },
    r90: { label: 'Trying again (turned right)', rot: 90, mode: 'gray', note: 'auto-rotated sideways photo' },
    r270: { label: 'Trying again (turned left)', rot: 270, mode: 'gray', note: 'auto-rotated sideways photo' },
    r180: { label: 'Trying again (upside down)', rot: 180, mode: 'gray', note: 'auto-rotated upside-down photo' }
  };

  async function read(src, opt) { // src: image URL or an already decoded canvas / image
    opt = opt || {}; const say = opt.progress || (() => {}), t0 = Date.now(), im = typeof src === 'string' ? await load(src) : src;
    let box = null; try { box = contentBox(im); } catch (e) { box = null; }
    box = box || { x: 0, y: 0, w: im.width, h: im.height };
    const L = Math.max(box.w, box.h), k = Math.max(0.1, Math.min(MAX_UP, TARGET / L)), kz = k < 1 ? Math.min(1, DETAIL / L) : k; // zoom pass keeps more detail on big photos
    const ocrCanvas = c => new Promise((ok, no) => c.toBlob(b => b ? ok(b) : no(new Error('encode')), 'image/png')).then(b => opt.ocr(b));
    async function run(step) {
      const c = draw(im, box, step.split ? kz : k, step.rot); step.mode === 'bin' ? binarize(c) : stretch(c);
      if (!step.split) return ocrCanvas(pad(c, 0.04));
      const parts = halves(c).map(h => pad(h, 0.04)), out = [];
      for (let i = 0; i < parts.length; i++) { say(step.label + ' (' + (i + 1) + ' of ' + parts.length + ')'); out.push(await ocrCanvas(parts[i])); }
      return out.join('\n');
    }
    let best = null, lastErr = null, n = 0, queue = [STEP.normal];
    while (queue.length) {
      const step = queue.shift();
      if (n > 0 && Date.now() - t0 > BUDGET) break;                // out of time: keep the best result so far
      say(step.label); n++;
      let text = ''; try { text = await run(step); } catch (e) { if (e && e.ocrFatal) throw e; lastErr = e; }
      const a = assess(text);
      if (!best || a.q > best.q) best = { text, q: a.q, cov: a.cov, label: step.label, rot: step.rot, note: step.note || '', tries: n };
      if (accept(a, step.rot)) break;
      if (n === 1) queue = [STEP.zoom, STEP.bin, STEP.r90, STEP.r270, STEP.r180];
    }
    if (!best || (!best.text.trim() && lastErr)) throw lastErr || new Error('ocr');
    return best;
  }
  const api = { read, quality, assess, contentBox };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.SmartScan = api;
})(typeof window !== 'undefined' ? window : globalThis);
